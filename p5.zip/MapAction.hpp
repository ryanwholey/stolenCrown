#ifndef MAPACTION_HPP
#define MAPACTION_HPP

class MapAction {
    private:
        int id;
        int x;
        int y;
        char icon;
        char key;
    public:
        MapAction(int, int, int, char, char);
        int getId();
        char getKey();
        int getX();
        int getY();
};

#endif
