#include "Room.hpp"

using std::string;
using std::ifstream;
using std::vector;
using std::list;

// temp
using std::cout;
using std::endl;

void Room::loadLayout(string filename)
{
    ifstream in;
    in.open(filename);
    string tmp, raw = "";

    while(!in.eof())
    {
        getline(in, tmp);
        raw += tmp + '\n';
        layout.push_back(tmp);
    }

    in.close();
    rawLayout = raw;
}

Room::Room(string filename)
{
    rawLayout = "";
    loadLayout(filename);
}

string Room::getRawLayout()
{
    vector<string> finalMap;
    int layoutSize = layout.size();
    bool isMap = false;
    for (int i = 0; i < layoutSize; i++)
    {
        if (layout.at(i).compare("</layout>") == 0)
        {
            isMap = false;
        }
        if (isMap)
        {
            finalMap.push_back(layout.at(i));
        }
        if (layout[i].compare("<layout>") == 0)
        {
            isMap = true;
        }
    }

    for (list<MapItem*>::const_iterator it = mapItems.begin(), end = mapItems.end(); it!= end; ++it) {
        int y = (*it) -> getY();
        int x = (*it) -> getX();
        char icon = (*it) -> getIcon();

        if (
            y < finalMap.size() &&
            y >= 0 &&
            x < finalMap.at(y).size() &&
            x >= 0
            )
        {
            finalMap.at(y).replace(x, 1, string(1, icon));
        }
    }

    string map = "";

    int size = finalMap.size();
    for (int i = 0; i < size; i++)
    {
        map += finalMap.at(i) + '\n';
    }

    return map;
}

void Room::addMapItem(MapItem* item)
{
    mapItems.push_back(item);
}

MapItem* Room::findMapItem(int id)
{
    MapItem *item = NULL;

    for (list<MapItem*>::const_iterator it = mapItems.begin(), end = mapItems.end(); it!= end; ++it)
    {
        int itemId = (*it) -> getId();

        if (id == itemId)
        {
            item = (*it);
        }
    }

    return item;
}


