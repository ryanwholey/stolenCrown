#ifndef MAPITEM_HPP
#define MAPITEM_HPP

#include <queue>

#include "MapAction.hpp"

using std::queue;


class MapItem
{
    private:
        static int count;
        int x;
        int y;
        char icon;
        char floorIcon;
    protected:
        int id;
        queue <MapAction*> *actionQueue;
    public:
        MapItem(int, int, char, queue<MapAction*>*);
        int getX();
        int getY();
        void setX(int);
        void setY(int);
        int getId();
        char getIcon();
};

#endif
