#include "MapAction.hpp"

MapAction::MapAction(int _id, int _x, int _y, char _icon, char _key) {
    id = _id;
    x = _x;
    y = _y;
    icon = _icon;
    key = _key;
}

char MapAction::getKey()
{
    return key;
}

int MapAction::getId()
{
    return id;
}

int MapAction::getX()
{
    return x;
}

int MapAction::getY()
{
    return y;
}
