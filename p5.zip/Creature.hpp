#ifndef CREATURE_HPP
#define CREATURE_HPP

#include <queue>

#include "MapItem.hpp"
#include "MapAction.hpp"

class Creature: public MapItem {

    public:
        Creature(int, int, char, std::queue<MapAction*>*);
        void goLeft();
        void goRight();
        void goUp();
        void goDown();
};

#endif
