#ifndef ROOM_HPP
#define ROOM_HPP

#include <string>
#include <fstream>
#include <vector>
#include <list>
//temp
#include <iostream>
#include <sstream>

#include "MapItem.hpp"

class Room
{
    private:
        std::string rawLayout;
        std::list <MapItem*> mapItems;
        std::vector<std::string> layout;

        void loadLayout(std::string);
        void createLayout(std::string);
    public:
        Room(std::string);
        std::string getRawLayout();
        MapItem* findMapItem(int);
        void addMapItem(MapItem*);
        void removeMapItem(int);
};

#endif
