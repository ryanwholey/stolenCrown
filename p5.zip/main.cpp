#include <iostream>
#include <thread>
#include <queue>
#include <cstdlib>
#include <string>
#include <curses.h>
#include <fstream>

#include "Room.hpp"
#include "MapAction.hpp"
#include "Creature.hpp"

using std::ifstream;
using std::thread;
using std::cout;
using std::endl;
using std::cin;
using std::queue;
using std::string;

void wait()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
}


void handleKeyPress(queue <MapAction*> *s, Creature* player)
{

    char ch = '\0';
    bool done  = false;
    while (!done) {
        ch = getch();
        if (ch != ERR)
        {
            switch (ch)
            {
                case 'h':
                    player -> goLeft();
                    break;
                case 'j':
                    player -> goDown();
                    break;
                case 'k':
                    player -> goUp();
                    break;
                case 'l':
                    player -> goRight();
                    break;
                case 'q':
                    s -> push(new MapAction(1,2,3,'@', ch));
                    done = true;
                    break;
                default:
                    break;
            }
        }
        wait();
    }
}


void initScrean()
{
    initscr();
    cbreak();
    noecho();
    scrollok(stdscr, TRUE);
    nodelay(stdscr, TRUE);
}

int main()
{
    queue <MapAction*> *q = new queue<MapAction*>();

    initScrean();
    Creature *player = new Creature(1, 1, '@', q);
    thread t(handleKeyPress, q, player);

    Room *r = new Room("rooms/001.txt");
    r -> addMapItem(player);
    clear();

    printw(r -> getRawLayout().c_str());

    bool done = false;
    while(!done)
    {
        while (!q -> empty())
        {
            MapAction *a = q -> front();

            if ((a -> getKey()) == 'q')
            {
                done = true;
            }

            MapItem *item = r -> findMapItem(a -> getId());
            item -> setX(a -> getX());
            item -> setY(a -> getY());

            addch(a -> getKey());

            q -> pop();
            delete a;

            clear();
            printw(r -> getRawLayout().c_str());
        }
        refresh();

        wait();
    }

    delete r;
    delete player;
    t.join();
    system("/bin/stty sane");
}

